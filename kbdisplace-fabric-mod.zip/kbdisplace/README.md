# KB Displace — Fabric 1.21.11

One-key knockback displacement macro.

Press key → yaw flicks → sprint forced → attack → camera restored.

## Keys
| Key | Action |
|-----|--------|
| V | Side (+90°) |
| B | Back (+180°) |
| N | Pull (face nearest target) |

## Build on GitHub
1. Push this repo to GitHub
2. Actions → Build runs automatically
3. Download artifact `kbdisplace-1.21.11` (the jar)

Or local:
```bash
./gradlew build --no-daemon
```
Jar → `build/libs/kbdisplace-1.0.0.jar`

## Requirements
- Minecraft 1.21.11
- Fabric Loader ≥ 0.16.9
- Fabric API 1.21.11
